# ScreenCast Android (Kotlin)

An Android screen-mirroring starter project using MediaProjection, a resizable VirtualDisplay, WebRTC, and a local browser receiver page.

## What is included

- `MediaProjectionService.kt`: foreground service and capture lifecycle.
- `ProjectionCapturer.kt`: MediaProjection-backed WebRTC capturer. It creates one VirtualDisplay per consent session and resizes that display on orientation changes.
- `AspectScaleManager.kt`: screen-size planning and 16:9 center-crop geometry.
- `AspectCropProcessor.kt`: actual per-frame crop; this is what fills a 16:9 TV without stretching.
- `ProjectionRtcSession.kt`: WebRTC offer/answer and ICE candidate exchange.
- `LocalReceiverServer.kt`: local HTTP page server and WebSocket signaling server.
- `receiver.html`: browser receiver page for the TV.
- `SsdpDeviceScanner.kt`: UPnP/DLNA MediaRenderer discovery for diagnostics. Discovery does not itself stream video to DLNA-only TVs.
- `.github/workflows/build-apk.yml`: optional GitHub Actions debug APK build.

## Requirements

- JDK 17.
- Android SDK Platform 36 and Build Tools 36.0.0.
- Gradle 8.13 / Android Gradle Plugin 8.13.2.
- A TV browser that supports WebRTC (RTCPeerConnection and remote video playback).
- Both devices on the same non-isolated Wi-Fi network.

The project uses `io.github.webrtc-sdk:android:150.7871.04` and Java-WebSocket 1.5.7. Gradle downloads these dependencies during the first build.

## Build

**Phone-only GitHub workflow:**

1. Create a public or private GitHub repository.
2. Upload `ScreenCastAndroid.zip` to the repository root without extracting it.
3. In GitHub, create `.github/workflows/build.yml` and paste the contents of the included `.github/workflows/build-apk.yml` file. GitHub needs this workflow file outside the ZIP so it can detect the workflow.
4. Open the repository's **Actions** tab, select **Build ScreenCast APK**, and press **Run workflow** (or push a commit to `main`).
5. When it succeeds, open the run and download the `ScreenCast-debug-apk` artifact.

The workflow supports either the ZIP uploaded as-is or an already extracted project. It installs JDK 17, Android SDK 36 and Gradle 8.13.

On a computer with Android Studio, open the extracted folder as an existing Gradle project and use Gradle 8.13. The project includes `gradle-wrapper.properties` but intentionally does not include the wrapper JAR/scripts; use the installed Gradle command:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

For a phone-only workflow, push the project to a GitHub repository and run **Actions → Build ScreenCast APK**. Download the `ScreenCast-debug-apk` artifact from the completed workflow.

## Use

1. Install the APK on the Android phone.
2. Connect the phone and TV to the same Wi-Fi network. Avoid guest Wi-Fi / AP isolation.
3. Tap **Start screen mirroring** and approve Android's screen-capture prompt.
4. On the TV, open the URL and PIN displayed by the app.
5. Keep the TV browser page open. The WebRTC video session starts after the receiver connects.
6. Use **Stop mirroring** to end the foreground service and release the capture session.

## Aspect-ratio behavior

- Portrait: capture retains the phone's portrait ratio and the TV receiver uses `object-fit: contain`; a 16:9 TV will naturally show side bars for portrait content.
- Landscape with auto fullscreen: capture first uses the phone's own aspect ratio (up to a 2400-pixel long edge). The WebRTC frame processor then center-crops to 16:9 and scales to 1920x1080. For a 2400x1080 phone display, this means a native 1920x1080 center crop. This fills the TV but cuts off content on the left/right of a 20:9 phone screen (or top/bottom if the source is narrower than 16:9).
- Landscape with auto fullscreen off: original aspect ratio is kept, so the TV may show bars.

The 1920x1080 output is a transport frame size, not a promise of 1080p source detail. A 3840x2160 stream is intentionally not enabled by default: it increases bandwidth/heat and does not create detail absent from the phone's display.

## Important compatibility and privacy notes

- This is a WebRTC browser-receiver implementation, not a Miracast/Wi-Fi Display transmitter. A TV advertising a DLNA MediaRenderer service is not automatically able to receive WebRTC. The UPnP scan is diagnostic only.
- A TV browser with no WebRTC support cannot use this receiver page. Browser security rules and firmware differences can also affect pages served from a phone's private `http://` address; test the exact TV browser before relying on this transport. A more robust commercial deployment would use HTTPS/WSS with a trusted certificate and, where needed, a native receiver app.
- Chromecast support would require a registered Cast receiver and a compatible live-media packaging path; it is not interchangeable with this browser receiver.
- WebRTC media is encrypted, but the local signaling page uses HTTP and WebSocket on the LAN and a six-digit session PIN. Use a trusted private Wi-Fi network and stop the session when finished.
- Some Android apps protect their video using DRM / secure surfaces. Android can return a black region for protected content; an ordinary third-party screen-capture app cannot bypass that protection.
- No microphone or device-audio capture is included in this starter.
- The sender can only be considered production-ready after device testing on the target Android version and the exact TV browser. Smart-TV browser WebRTC implementations vary by manufacturer and firmware.

## Release checklist before publishing

- Test MediaProjection consent and rotation on API 26, 31, 34, 35, and 36 devices. API 34+ uses `onCapturedContentResize()` for authoritative capture-size updates; `OrientationEventListener` remains as a compatibility fallback.
- Validate H.264 hardware encoder behavior, bitrate adaptation, reconnects, and memory pressure on lower-end phones.
- Add a TLS/authenticated receiver channel if the product will be used outside trusted home Wi-Fi.
- Add TURN fallback for networks that block peer-to-peer traffic.
- Add a device-specific TV receiver app or a Google Cast receiver path for TVs whose browsers do not support WebRTC.
