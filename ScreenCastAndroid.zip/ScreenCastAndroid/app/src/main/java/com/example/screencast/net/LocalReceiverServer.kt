package com.example.screencast.net

import android.content.Context
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hosts receiver.html over HTTP and a tiny WebSocket signaling endpoint on the phone.
 * The TV browser loads http://PHONE_IP:8081/?pin=XXXXXX. SDP/ICE messages use :8082.
 */
class LocalReceiverServer(
    private val context: Context,
    private val pin: String,
    private val listener: Listener
) {
    interface Listener {
        fun onReceiverConnected()
        fun onReceiverDisconnected()
        fun onSignalMessage(message: String)
    }

    private val httpServer = ReceiverHttpServer(context, 8081)
    private val wsServer = SignalWebSocketServer(8082, pin, listener)

    fun start() {
        httpServer.start()
        wsServer.start()
    }

    fun send(message: String) = wsServer.sendToReceiver(message)

    fun stop() {
        runCatching { wsServer.stop(500) }
        httpServer.stop()
    }

    private class ReceiverHttpServer(
        private val context: Context,
        private val port: Int
    ) {
        private val running = AtomicBoolean(false)
        private var serverSocket: ServerSocket? = null
        private var worker: Thread? = null

        fun start() {
            if (!running.compareAndSet(false, true)) return
            worker = Thread({
                try {
                    serverSocket = ServerSocket(port)
                    while (running.get()) {
                        val client = serverSocket?.accept() ?: break
                        Thread { respond(client) }.start()
                    }
                } catch (_: Exception) {
                    // stop() closes the socket and intentionally exits this loop.
                }
            }, "ScreenCast-HttpServer").apply { isDaemon = true; start() }
        }

        private fun respond(socket: Socket) {
            socket.use { client ->
                client.soTimeout = 3000
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val requestLine = reader.readLine().orEmpty()
                while (true) {
                    val header = reader.readLine() ?: break
                    if (header.isEmpty()) break
                }

                val path = requestLine.split(' ').getOrNull(1).orEmpty()
                if (!path.startsWith("/")) {
                    writeResponse(client, 400, "text/plain", "Bad request")
                    return
                }

                val html = context.assets.open("receiver.html").bufferedReader().use { it.readText() }
                writeResponse(client, 200, "text/html; charset=utf-8", html)
            }
        }

        private fun writeResponse(socket: Socket, status: Int, mime: String, body: String) {
            val bytes = body.toByteArray(StandardCharsets.UTF_8)
            val header = buildString {
                append("HTTP/1.1 $status ${if (status == 200) "OK" else "Bad Request"}\r\n")
                append("Content-Type: $mime\r\n")
                append("Content-Length: ${bytes.size}\r\n")
                append("Cache-Control: no-store\r\n")
                append("Connection: close\r\n\r\n")
            }
            socket.getOutputStream().apply {
                write(header.toByteArray(StandardCharsets.US_ASCII))
                write(bytes)
                flush()
            }
        }

        fun stop() {
            running.set(false)
            runCatching { serverSocket?.close() }
            serverSocket = null
            worker = null
        }
    }

    private class SignalWebSocketServer(
        port: Int,
        private val pin: String,
        private val listener: Listener
    ) : WebSocketServer(InetSocketAddress("0.0.0.0", port)) {
        @Volatile private var receiver: WebSocket? = null

        override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
            val rawQuery = conn.resourceDescriptor.substringAfter('?', "")
            val suppliedPin = rawQuery.split('&')
                .firstOrNull { it.startsWith("pin=") }
                ?.substringAfter("pin=")
                ?.let { URLDecoder.decode(it, "UTF-8") }
            if (suppliedPin != pin) {
                conn.close(1008, "Invalid session PIN")
                return
            }
            receiver?.close(1000, "A new receiver connected")
            receiver = conn
            listener.onReceiverConnected()
        }

        override fun onMessage(conn: WebSocket, message: String) {
            if (conn == receiver) listener.onSignalMessage(message)
        }

        override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
            if (conn == receiver) {
                receiver = null
                listener.onReceiverDisconnected()
            }
        }

        override fun onError(conn: WebSocket?, ex: Exception) {
            // The foreground service owns lifecycle and can restart the server if required.
        }

        override fun onStart() = Unit

        fun sendToReceiver(message: String) {
            val current = receiver
            if (current != null && current.isOpen) runCatching { current.send(message) }
        }
    }
}
