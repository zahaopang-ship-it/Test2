package com.example.screencast.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.view.Surface
import org.webrtc.CapturerObserver
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoFrame
import org.webrtc.VideoSink

/**
 * WebRTC VideoCapturer backed by MediaProjection and a resizable VirtualDisplay.
 * Unlike ScreenCapturerAndroid's stock capturer, this implementation accepts
 * the current display density rather than hard-coding a VirtualDisplay DPI.
 */
class ProjectionCapturer(
    private val permissionResultData: Intent,
    private val densityDpi: () -> Int,
    private val onProjectionStopped: () -> Unit,
    private val onCapturedContentResize: (Int, Int) -> Unit
) : VideoCapturer, VideoSink {
    private var helper: SurfaceTextureHelper? = null
    private var observer: CapturerObserver? = null
    private var projectionManager: MediaProjectionManager? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var outputSurface: Surface? = null
    private var width = 0
    private var height = 0
    private var disposed = false
    @Volatile private var stoppedBySystem = false

    override fun initialize(
        surfaceTextureHelper: SurfaceTextureHelper,
        applicationContext: Context,
        capturerObserver: CapturerObserver
    ) {
        check(!disposed) { "Capturer has already been disposed" }
        helper = surfaceTextureHelper
        observer = capturerObserver
        projectionManager = applicationContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager
    }

    override fun startCapture(width: Int, height: Int, framerate: Int) {
        check(!disposed) { "Capturer has already been disposed" }
        val textureHelper = checkNotNull(helper) { "initialize() must be called first" }
        this.width = width
        this.height = height

        // The service must already be running as a mediaProjection foreground service.
        projection = checkNotNull(projectionManager).getMediaProjection(
            Activity.RESULT_OK,
            permissionResultData
        )

        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                stoppedBySystem = true
                onProjectionStopped()
            }

            // Android 14+ reports the true captured-content dimensions here.
            // The service uses them to resize the existing VirtualDisplay and Surface.
            override fun onCapturedContentResize(width: Int, height: Int) {
                if (width > 0 && height > 0) onCapturedContentResize.invoke(width, height)
            }
        }
        projection!!.registerCallback(projectionCallback!!, textureHelper.handler)
        createOrResizeVirtualDisplay()
        observer?.onCapturerStarted(true)
        textureHelper.startListening(this)
    }

    override fun changeCaptureFormat(width: Int, height: Int, framerate: Int) {
        if (disposed || width <= 0 || height <= 0) return
        this.width = width
        this.height = height
        val textureHelper = helper ?: return
        textureHelper.handler.post {
            if (!disposed) createOrResizeVirtualDisplay()
        }
    }

    private fun createOrResizeVirtualDisplay() {
        val textureHelper = helper ?: return
        textureHelper.setTextureSize(width, height)
        val surface = Surface(textureHelper.surfaceTexture)

        if (virtualDisplay == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            // Before Android 12, recreating after a size change avoids incorrect scaling.
            virtualDisplay?.release()
            outputSurface?.release()
            outputSurface = surface
            virtualDisplay = checkNotNull(projection).createVirtualDisplay(
                "ScreenCastVirtualDisplay",
                width,
                height,
                densityDpi().coerceAtLeast(120),
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface,
                null,
                null
            )
        } else {
            virtualDisplay?.resize(width, height, densityDpi().coerceAtLeast(120))
            virtualDisplay?.setSurface(surface)
            outputSurface?.release()
            outputSurface = surface
        }
    }

    override fun onFrame(frame: VideoFrame) {
        observer?.onFrameCaptured(frame)
    }

    override fun stopCapture() {
        val textureHelper = helper
        if (textureHelper != null) {
            runCatching { textureHelper.stopListening() }
        }
        observer?.onCapturerStopped()
        virtualDisplay?.release()
        virtualDisplay = null
        outputSurface?.release()
        outputSurface = null

        val activeProjection = projection
        val callback = projectionCallback
        if (activeProjection != null && callback != null) {
            runCatching { activeProjection.unregisterCallback(callback) }
        }
        if (activeProjection != null && !stoppedBySystem) {
            runCatching { activeProjection.stop() }
        }
        projection = null
        projectionCallback = null
    }

    override fun dispose() {
        disposed = true
        helper = null
        observer = null
    }

    override fun isScreencast(): Boolean = true
}
