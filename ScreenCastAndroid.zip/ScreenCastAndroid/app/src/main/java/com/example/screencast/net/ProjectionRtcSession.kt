package com.example.screencast.net

import org.json.JSONObject
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.VideoTrack

/** Creates one WebRTC peer per connected TV browser and forwards screen video. */
class ProjectionRtcSession(
    private val factory: PeerConnectionFactory,
    private val videoTrack: VideoTrack,
    private val sendSignal: (String) -> Unit
) {
    private var peer: PeerConnection? = null
    private val pendingRemoteCandidates = java.util.concurrent.CopyOnWriteArrayList<IceCandidate>()
    @Volatile private var remoteDescriptionSet = false

    fun createOffer() {
        closePeer()
        pendingRemoteCandidates.clear()
        remoteDescriptionSet = false
        val rtcConfig = PeerConnection.RTCConfiguration(
            listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
            )
        ).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }

        peer = factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) = Unit
            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit
            override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) = Unit
            override fun onAddStream(stream: org.webrtc.MediaStream) = Unit
            override fun onRemoveStream(stream: org.webrtc.MediaStream) = Unit
            override fun onDataChannel(dataChannel: org.webrtc.DataChannel) = Unit
            override fun onRenegotiationNeeded() = Unit

            override fun onIceCandidate(candidate: IceCandidate) {
                val json = JSONObject()
                    .put("type", "candidate")
                    .put("candidate", JSONObject()
                        .put("sdpMid", candidate.sdpMid)
                        .put("sdpMLineIndex", candidate.sdpMLineIndex)
                        .put("candidate", candidate.sdp))
                sendSignal(json.toString())
            }
        }) ?: return

        peer?.addTrack(videoTrack, listOf("screen-stream"))
        peer?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(description: SessionDescription) {
                val currentPeer = peer ?: return
                currentPeer.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        val sdp = JSONObject()
                            .put("type", "offer")
                            .put("sdp", description.description)
                        sendSignal(JSONObject().put("type", "offer").put("sdp", sdp).toString())
                    }
                    override fun onSetFailure(error: String) = sendError(error)
                    override fun onCreateSuccess(description: SessionDescription) = Unit
                    override fun onCreateFailure(error: String) = sendError(error)
                }, description)
            }
            override fun onCreateFailure(error: String) = sendError(error)
            override fun onSetSuccess() = Unit
            override fun onSetFailure(error: String) = sendError(error)
        }, MediaConstraints())
    }

    fun onSignalMessage(raw: String) {
        val currentPeer = peer ?: return
        runCatching {
            val message = JSONObject(raw)
            when (message.optString("type")) {
                "answer" -> {
                    val sdp = message.getJSONObject("sdp")
                    val type = SessionDescription.Type.fromCanonicalForm(sdp.getString("type"))
                    currentPeer.setRemoteDescription(object : SdpObserver {
                        override fun onSetSuccess() {
                            remoteDescriptionSet = true
                            pendingRemoteCandidates.forEach { currentPeer.addIceCandidate(it) }
                            pendingRemoteCandidates.clear()
                        }
                        override fun onSetFailure(error: String) = sendError(error)
                        override fun onCreateSuccess(description: SessionDescription) = Unit
                        override fun onCreateFailure(error: String) = sendError(error)
                    }, SessionDescription(type, sdp.getString("sdp")))
                }
                "candidate" -> {
                    val c = message.getJSONObject("candidate")
                    val candidate = IceCandidate(
                        c.optString("sdpMid", "0"),
                        c.optInt("sdpMLineIndex", 0),
                        c.getString("candidate")
                    )
                    if (remoteDescriptionSet) currentPeer.addIceCandidate(candidate)
                    else pendingRemoteCandidates += candidate
                }
            }
        }.onFailure { sendError(it.message ?: "Invalid WebRTC signaling message") }
    }

    fun closePeer() {
        peer?.close()
        peer?.dispose()
        peer = null
        pendingRemoteCandidates.clear()
        remoteDescriptionSet = false
    }

    private fun sendError(message: String) {
        sendSignal(JSONObject().put("type", "error").put("message", message).toString())
    }

}

/** Centralizes WebRTC native initialization for the Android process. */
object WebRtcFactory {
    @Volatile private var initialized = false

    @Synchronized
    fun initialize(context: android.content.Context) {
        if (initialized) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
        )
        initialized = true
    }

    fun create(context: android.content.Context, eglBase: EglBase): PeerConnectionFactory {
        initialize(context)
        return PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
    }
}
