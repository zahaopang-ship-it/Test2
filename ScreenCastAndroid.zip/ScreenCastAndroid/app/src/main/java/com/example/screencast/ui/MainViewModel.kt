package com.example.screencast.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.screencast.net.DiscoveredDevice
import com.example.screencast.net.SsdpDeviceScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _devices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val devices: StateFlow<List<DiscoveredDevice>> = _devices

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning

    private val _autoFullscreen = MutableStateFlow(true)
    val autoFullscreen: StateFlow<Boolean> = _autoFullscreen

    fun setAutoFullscreen(enabled: Boolean) {
        _autoFullscreen.value = enabled
    }

    fun scan(context: Context) {
        if (_scanning.value) return
        viewModelScope.launch(Dispatchers.IO) {
            _scanning.value = true
            try {
                _devices.value = SsdpDeviceScanner.scan(context.applicationContext)
            } finally {
                _scanning.value = false
            }
        }
    }
}
