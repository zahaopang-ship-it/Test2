package com.example.screencast.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Display
import android.view.OrientationEventListener
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import com.example.screencast.net.LocalReceiverServer
import com.example.screencast.net.ProjectionRtcSession
import com.example.screencast.net.WebRtcFactory
import org.webrtc.EglBase
import org.webrtc.PeerConnectionFactory
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack

/** Owns the foreground capture session, VirtualDisplay, orientation changes and WebRTC stack. */
class MediaProjectionService : Service(), LocalReceiverServer.Listener {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scaleManager = AspectScaleManager()

    private var permissionData: Intent? = null
    private var autoFullscreen = true
    private var currentCaptureWidth = 0
    private var currentCaptureHeight = 0
    private var currentRotation = Display.INVALID_DISPLAY

    private var orientationListener: OrientationEventListener? = null
    private var receiverServer: LocalReceiverServer? = null
    private var eglBase: EglBase? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var peerFactory: PeerConnectionFactory? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var cropProcessor: AspectCropProcessor? = null
    private var capturer: ProjectionCapturer? = null
    private var rtcSession: ProjectionRtcSession? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSession()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE_SETTINGS -> {
                autoFullscreen = intent.getBooleanExtra(EXTRA_AUTO_FULLSCREEN, autoFullscreen)
                refreshDisplayGeometry(force = true)
                return START_STICKY
            }
            ACTION_START -> {
                if (capturer != null) return START_STICKY
                permissionData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                autoFullscreen = intent.getBooleanExtra(EXTRA_AUTO_FULLSCREEN, true)
                val pin = intent.getStringExtra(EXTRA_PIN) ?: "000000"
                if (permissionData == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startAsForeground()
                startSession(pin)
            }
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen casting", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ScreenCast is active")
            .setContentText("Your screen is available to the TV on this Wi-Fi network")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startSession(pin: String) {
        try {
            val initial = displaySize()
            val initialLandscape = initial.first > initial.second
            val plan = scaleManager.createPlan(initial.first, initial.second, initialLandscape, autoFullscreen)
            currentCaptureWidth = plan.captureWidth
            currentCaptureHeight = plan.captureHeight
            currentRotation = defaultDisplay()?.rotation ?: Display.ROTATION_0

            WebRtcFactory.initialize(this)
            eglBase = EglBase.create()
            surfaceTextureHelper = SurfaceTextureHelper.create("ScreenCastCapture", eglBase!!.eglBaseContext)
            peerFactory = WebRtcFactory.create(this, eglBase!!)
            videoSource = peerFactory!!.createVideoSource(true)

            cropProcessor = AspectCropProcessor(scaleManager).apply {
                update(initialLandscape, autoFullscreen)
            }
            videoSource!!.setVideoProcessor(cropProcessor)

            capturer = ProjectionCapturer(
                permissionResultData = checkNotNull(permissionData),
                densityDpi = { resources.configuration.densityDpi },
                onProjectionStopped = { mainHandler.post { stopSession(); stopSelf() } },
                onCapturedContentResize = { width, height ->
                    mainHandler.post { applyCapturedContentSize(width, height) }
                }
            )
            capturer!!.initialize(surfaceTextureHelper!!, applicationContext, videoSource!!.capturerObserver)
            capturer!!.startCapture(plan.captureWidth, plan.captureHeight, 30)

            videoTrack = peerFactory!!.createVideoTrack("screen-track", videoSource)
            rtcSession = ProjectionRtcSession(
                factory = peerFactory!!,
                videoTrack = videoTrack!!,
                sendSignal = { payload -> receiverServer?.send(payload) }
            )

            receiverServer = LocalReceiverServer(this, pin, this).also { it.start() }
            enableOrientationListener()
        } catch (error: Exception) {
            android.util.Log.e(TAG, "Unable to start screen casting", error)
            stopSession()
            stopSelf()
        }
    }

    private fun enableOrientationListener() {
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                // Display rotation updates shortly after the physical orientation event.
                mainHandler.removeCallbacks(refreshRunnable)
                mainHandler.postDelayed(refreshRunnable, 250)
            }
        }.also { if (it.canDetectOrientation()) it.enable() }
    }

    private val refreshRunnable = Runnable { refreshDisplayGeometry() }

    /**
     * Preferred resize path on Android 14+: use the dimensions reported by MediaProjection,
     * rather than relying only on display metrics which can be stale during rotation.
     */
    private fun applyCapturedContentSize(width: Int, height: Int) {
        if (capturer == null || width <= 0 || height <= 0) return
        val landscape = width > height
        val plan = scaleManager.createPlan(width, height, landscape, autoFullscreen)
        cropProcessor?.update(landscape, autoFullscreen)
        if (plan.captureWidth != currentCaptureWidth || plan.captureHeight != currentCaptureHeight) {
            currentCaptureWidth = plan.captureWidth
            currentCaptureHeight = plan.captureHeight
            capturer?.changeCaptureFormat(plan.captureWidth, plan.captureHeight, 30)
        }
        currentRotation = defaultDisplay()?.rotation ?: currentRotation
    }

    /** OrientationEventListener fallback for Android versions without captured-size callbacks. */
    private fun refreshDisplayGeometry(force: Boolean = false) {
        if (capturer == null) return
        val display = defaultDisplay() ?: return
        val rotation = display.rotation
        if (rotation == currentRotation && !force) return

        val size = displaySize()
        val landscape = size.first > size.second
        val plan = scaleManager.createPlan(size.first, size.second, landscape, autoFullscreen)
        cropProcessor?.update(landscape, autoFullscreen)

        if (plan.captureWidth != currentCaptureWidth || plan.captureHeight != currentCaptureHeight) {
            currentCaptureWidth = plan.captureWidth
            currentCaptureHeight = plan.captureHeight
            // Resizes the existing VirtualDisplay. It does not create a second projection session.
            capturer?.changeCaptureFormat(plan.captureWidth, plan.captureHeight, 30)
        }
        currentRotation = rotation
    }

    @Suppress("DEPRECATION")
    private fun displaySize(): Pair<Int, Int> {
        val display = defaultDisplay() ?: return Pair(1080, 1920)
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return Pair(metrics.widthPixels.coerceAtLeast(1), metrics.heightPixels.coerceAtLeast(1))
    }

    private fun defaultDisplay(): Display? =
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)

    override fun onReceiverConnected() {
        mainHandler.post { rtcSession?.createOffer() }
    }

    override fun onReceiverDisconnected() {
        mainHandler.post { rtcSession?.closePeer() }
    }

    override fun onSignalMessage(message: String) {
        mainHandler.post { rtcSession?.onSignalMessage(message) }
    }

    private fun stopSession() {
        orientationListener?.disable()
        orientationListener = null
        mainHandler.removeCallbacks(refreshRunnable)

        receiverServer?.stop()
        receiverServer = null
        rtcSession?.closePeer()
        rtcSession = null

        runCatching { capturer?.stopCapture() }
        capturer?.dispose()
        capturer = null
        videoTrack?.dispose()
        videoTrack = null
        videoSource?.dispose()
        videoSource = null
        surfaceTextureHelper?.dispose()
        surfaceTextureHelper = null
        peerFactory?.dispose()
        peerFactory = null
        eglBase?.release()
        eglBase = null
        permissionData = null
    }

    override fun onDestroy() {
        stopSession()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.screencast.action.START"
        const val ACTION_STOP = "com.example.screencast.action.STOP"
        const val ACTION_UPDATE_SETTINGS = "com.example.screencast.action.UPDATE_SETTINGS"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_AUTO_FULLSCREEN = "auto_fullscreen"
        const val EXTRA_PIN = "pin"
        private const val CHANNEL_ID = "screencast_capture"
        private const val NOTIFICATION_ID = 41
        private const val TAG = "ScreenCastService"
    }
}
