package com.example.screencast.net

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL

/**
 * Finds UPnP/DLNA MediaRenderer devices on the local subnet.
 * This is discovery only; a DLNA renderer is not automatically a WebRTC receiver.
 */
data class DiscoveredDevice(
    val name: String,
    val location: String,
    val serviceType: String
)

object SsdpDeviceScanner {
    suspend fun scan(context: Context): List<DiscoveredDevice> = withContext(Dispatchers.IO) {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val multicastLock = runCatching {
            wifi.createMulticastLock("ScreenCast-SSDP").apply {
                setReferenceCounted(false)
                acquire()
            }
        }.getOrNull()

        val found = linkedMapOf<String, DiscoveredDevice>()
        val search = (
            "M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\n" +
                "MX: 2\r\n" +
                "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"
            ).toByteArray()

        try {
            DatagramSocket().use { socket ->
                socket.broadcast = true
                socket.soTimeout = 500
                val target = InetAddress.getByName("239.255.255.250")
                socket.send(DatagramPacket(search, search.size, target, 1900))

                val deadline = System.currentTimeMillis() + 3500
                val buffer = ByteArray(8192)
                while (System.currentTimeMillis() < deadline) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val response = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        val location = response.lineSequence()
                            .firstOrNull { it.startsWith("LOCATION:", ignoreCase = true) }
                            ?.substringAfter(':')?.trim() ?: continue
                        val serviceType = response.lineSequence()
                            .firstOrNull { it.startsWith("ST:", ignoreCase = true) }
                            ?.substringAfter(':')?.trim().orEmpty()
                        if (!found.containsKey(location)) {
                            found[location] = DiscoveredDevice(
                                name = readFriendlyName(location) ?: packet.address.hostAddress.orEmpty(),
                                location = location,
                                serviceType = serviceType
                            )
                        }
                    } catch (_: java.net.SocketTimeoutException) {
                        // Continue until the discovery window ends.
                    }
                }
            }
        } catch (_: Exception) {
            // Wi-Fi multicast may be unavailable on some OEM builds.
        } finally {
            runCatching { if (multicastLock?.isHeld == true) multicastLock.release() }
        }
        found.values.toList()
    }

    private fun readFriendlyName(location: String): String? = runCatching {
        val connection = URL(location).openConnection()
        connection.connectTimeout = 900
        connection.readTimeout = 900
        val xml = connection.getInputStream().bufferedReader().use { it.readText() }
        Regex("<friendlyName>(.*?)</friendlyName>", RegexOption.IGNORE_CASE)
            .find(xml)?.groupValues?.getOrNull(1)?.replace("&amp;", "&")
    }.getOrNull()
}
