package com.example.screencast.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.screencast.capture.MediaProjectionService
import kotlinx.coroutines.launch
import java.net.NetworkInterface
import java.security.SecureRandom

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private lateinit var statusText: TextView
    private lateinit var receiverUrlText: TextView
    private lateinit var devicesText: TextView
    private lateinit var scanButton: Button
    private var mirroringRequested = false

    private val captureConsent = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            startCaptureService(result.data!!)
        } else {
            statusText.text = "Screen capture permission was not granted."
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // The FGS can still run if notification permission is denied; proceed with capture consent.
        requestCaptureConsent()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.devices.collect { devices ->
                        devicesText.text = if (devices.isEmpty()) {
                            "No UPnP/DLNA renderers found yet. You can still try the browser receiver URL."
                        } else {
                            devices.joinToString("\n\n") {
                                "• ${it.name}\n  ${it.location}"
                            } + "\n\nNote: discovery does not guarantee WebRTC browser support."
                        }
                    }
                }
                launch {
                    viewModel.scanning.collect { scanButton.text = if (it) "Scanning…" else "Scan Wi-Fi devices" }
                }
            }
        }
    }

    private fun buildUi() {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(TextView(this).apply {
            text = "ScreenCast"
            textSize = 28f
            setPadding(0, 0, 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "Mirror this phone to a Smart TV over the same Wi-Fi network."
            textSize = 15f
        })

        val fullscreenSwitch = Switch(this).apply {
            text = "Auto Fullscreen on Landscape (16:9 crop)"
            isChecked = viewModel.autoFullscreen.value
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, enabled ->
                viewModel.setAutoFullscreen(enabled)
                if (mirroringRequested) {
                    startService(Intent(this@MainActivity, MediaProjectionService::class.java).apply {
                        action = MediaProjectionService.ACTION_UPDATE_SETTINGS
                        putExtra(MediaProjectionService.EXTRA_AUTO_FULLSCREEN, enabled)
                    })
                }
            }
        }
        root.addView(fullscreenSwitch)

        root.addView(Button(this).apply {
            text = "Start screen mirroring"
            setOnClickListener { startFlow() }
        }, matchWidth())

        root.addView(Button(this).apply {
            text = "Stop mirroring"
            setOnClickListener {
                startService(Intent(this@MainActivity, MediaProjectionService::class.java).apply {
                    action = MediaProjectionService.ACTION_STOP
                })
                mirroringRequested = false
                statusText.text = "Mirroring stopped."
                receiverUrlText.text = ""
            }
        }, matchWidth())

        statusText = TextView(this).apply {
            text = "Status: not connected"
            textSize = 14f
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(statusText)

        root.addView(TextView(this).apply {
            text = "Open this address in the TV browser after starting:"
            textSize = 14f
        })
        receiverUrlText = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(16))
            setTextIsSelectable(true)
        }
        root.addView(receiverUrlText)

        scanButton = Button(this).apply {
            text = "Scan Wi-Fi devices"
            setOnClickListener { viewModel.scan(this@MainActivity) }
        }
        root.addView(scanButton, matchWidth())

        devicesText = TextView(this).apply {
            text = "UPnP/DLNA devices will appear here."
            textSize = 14f
            setPadding(0, dp(12), 0, dp(12))
            setTextIsSelectable(true)
        }
        root.addView(devicesText)

        root.addView(TextView(this).apply {
            text = "Compatibility: the TV must have a browser with WebRTC support. UPnP/DLNA discovery is informational; it does not turn a DLNA-only TV into a WebRTC receiver. Keep both devices on the same trusted Wi-Fi network."
            textSize = 13f
            setPadding(0, dp(12), 0, 0)
        })

        setContentView(scroll)
    }

    private fun startFlow() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestCaptureConsent()
        }
    }

    private fun requestCaptureConsent() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // This app mirrors the complete display, not a single app window.
        val consentIntent = if (Build.VERSION.SDK_INT >= 34) {
            projectionManager.createScreenCaptureIntent(
                android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
            )
        } else {
            projectionManager.createScreenCaptureIntent()
        }
        captureConsent.launch(consentIntent)
    }

    private fun startCaptureService(data: Intent) {
        val pin = SecureRandom().nextInt(900_000).plus(100_000).toString()
        val ip = localIpv4Address()
        val launchIntent = Intent(this, MediaProjectionService::class.java).apply {
            action = MediaProjectionService.ACTION_START
            putExtra(MediaProjectionService.EXTRA_RESULT_DATA, data)
            putExtra(MediaProjectionService.EXTRA_AUTO_FULLSCREEN, viewModel.autoFullscreen.value)
            putExtra(MediaProjectionService.EXTRA_PIN, pin)
        }
        ContextCompat.startForegroundService(this, launchIntent)
        mirroringRequested = true
        receiverUrlText.text = if (ip != null) {
            "http://$ip:8081/?pin=$pin\nPIN: $pin"
        } else {
            "Could not determine phone IP. Check that Wi-Fi is connected. PIN: $pin"
        }
        statusText.text = "Capture permission granted. Open the URL on the TV and wait for WebRTC to connect."
    }

    private fun localIpv4Address(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { iface ->
                if (iface.name.startsWith("wlan", true) || iface.name.startsWith("wifi", true)) 0 else 1
            }
            .asSequence()
            .flatMap { it.inetAddresses.toList().asSequence() }
            .firstOrNull { it is java.net.Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress
    }.getOrNull()

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
