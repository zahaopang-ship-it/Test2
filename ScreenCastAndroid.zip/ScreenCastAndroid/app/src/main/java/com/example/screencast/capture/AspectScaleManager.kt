package com.example.screencast.capture

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Computes the VirtualDisplay capture size and the video frame crop.
 *
 * The capture surface follows the phone's actual aspect ratio. In landscape,
 * the VideoProcessor crops the source to 16:9 and scales it to 1920x1080.
 * Portrait mode is passed through unchanged.
 */
class AspectScaleManager(
    private val maxCaptureLongEdge: Int = 2400,
    private val landscapeOutputWidth: Int = 1920,
    private val landscapeOutputHeight: Int = 1080
) {
    data class Plan(
        val captureWidth: Int,
        val captureHeight: Int,
        val outputWidth: Int,
        val outputHeight: Int,
        val cropToSixteenNine: Boolean
    )

    fun createPlan(
        displayWidth: Int,
        displayHeight: Int,
        landscape: Boolean,
        autoFullscreen: Boolean
    ): Plan {
        require(displayWidth > 0 && displayHeight > 0) {
            "Display dimensions must be positive"
        }

        // Keep the source aspect ratio while limiting the largest dimension to 1920.
        val scale = min(1.0, maxCaptureLongEdge.toDouble() / max(displayWidth, displayHeight))
        val captureWidth = even((displayWidth * scale).roundToInt())
        val captureHeight = even((displayHeight * scale).roundToInt())

        val crop = landscape && autoFullscreen
        return if (crop) {
            Plan(
                captureWidth = captureWidth,
                captureHeight = captureHeight,
                outputWidth = landscapeOutputWidth,
                outputHeight = landscapeOutputHeight,
                cropToSixteenNine = true
            )
        } else {
            Plan(
                captureWidth = captureWidth,
                captureHeight = captureHeight,
                outputWidth = captureWidth,
                outputHeight = captureHeight,
                cropToSixteenNine = false
            )
        }
    }

    /** Center-crop rectangle for a 16:9 result. */
    fun cropRect(sourceWidth: Int, sourceHeight: Int): IntArray {
        require(sourceWidth > 0 && sourceHeight > 0)
        val targetRatio = 16.0 / 9.0
        val sourceRatio = sourceWidth.toDouble() / sourceHeight

        return if (sourceRatio > targetRatio) {
            val cropWidth = even((sourceHeight * targetRatio).roundToInt())
            intArrayOf(even((sourceWidth - cropWidth) / 2), 0, cropWidth, sourceHeight)
        } else {
            val cropHeight = even((sourceWidth / targetRatio).roundToInt())
            intArrayOf(0, even((sourceHeight - cropHeight) / 2), sourceWidth, cropHeight)
        }
    }

    private fun even(value: Int): Int = max(2, value - (value and 1))
}
