package com.example.screencast.capture

import org.webrtc.VideoFrame
import org.webrtc.VideoProcessor
import org.webrtc.VideoSink

/** Applies center-crop 16:9 only while landscape auto-fullscreen is enabled. */
class AspectCropProcessor(
    private val scaleManager: AspectScaleManager
) : VideoProcessor {
    @Volatile private var landscapeFullscreen = false
    @Volatile private var sink: VideoSink? = null

    fun update(landscape: Boolean, autoFullscreen: Boolean) {
        landscapeFullscreen = landscape && autoFullscreen
    }

    override fun setSink(sink: VideoSink?) {
        this.sink = sink
    }

    override fun onCapturerStarted(success: Boolean) = Unit
    override fun onCapturerStopped() = Unit

    override fun onFrameCaptured(frame: VideoFrame) {
        val output = sink ?: return
        if (!landscapeFullscreen) {
            output.onFrame(frame)
            return
        }

        val source = frame.buffer
        val crop = scaleManager.cropRect(source.width, source.height)
        val croppedBuffer = source.cropAndScale(
            crop[0], crop[1], crop[2], crop[3], 1920, 1080
        )
        val croppedFrame = VideoFrame(croppedBuffer, frame.rotation, frame.timestampNs)
        try {
            output.onFrame(croppedFrame)
        } finally {
            croppedFrame.release()
        }
    }
}
